<?php
/*
Plugin Name: Google Tag Manager for Hackers
Plugin URI:   https://github.com/dgitis/WP-GTM
Description:  Adds Google Tag Manager using either a hack that should work with most themes or the new wp_body_open hook planned for 5.0. You will need to add <?php wp_body_open(); ?> immediately after the opening body tag in your child theme to get this to work.
Version:      1.0
Author:       Damon Gudaitis
Author URI:   http://www.caretjuice.com/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  googletagmanager
*/

if (!defined('WP_CONTENT_URL'))
      define('WP_CONTENT_URL', get_option('siteurl').'/wp-content');
if (!defined('WP_CONTENT_DIR'))
      define('WP_CONTENT_DIR', ABSPATH.'wp-content');
if (!defined('WP_PLUGIN_URL'))
      define('WP_PLUGIN_URL', WP_CONTENT_URL.'/plugins');
if (!defined('WP_PLUGIN_DIR'))
      define('WP_PLUGIN_DIR', WP_CONTENT_DIR.'/plugins');

if (!function_exists('wp_body_open')){
	function wp_body_open() { 
		do_action('wp_body_open'); 
	}
}
function activate_googletag() {
  add_option('tag_id', 'GTM-xxxxxxxxx');
}

function deactive_googletag() {
  delete_option('tag_id');
}

function admin_init_googletagmanager() {
  register_setting('googletagmanager', 'tag_id');
	register_setting('googletagmanager', 'placement_method');
}

function admin_menu_googletagmanager() {
  add_options_page('Google Tag Manager', 'Google Tag Manager', 'manage_options', 'googletagmanager', 'options_page_googletagmanager');
}

function options_page_googletagmanager() {
  include(WP_PLUGIN_DIR.'/hackers-google-tag-manager/options.php');  
}

function googletagmanagerhead() {
	$tag_id = get_option('tag_id');
?>
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','<?php echo $tag_id ?>');</script>
	<!-- End Google Tag Manager -->
<?php
}

function googletagmanagerbody() {
	$tag_id = get_option('tag_id');
	?>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo $tag_id ?>"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->


	<?php
}

register_activation_hook(__FILE__, 'activate_googletagmanager');
register_deactivation_hook(__FILE__, 'deactive_googletagmanager');

if (is_admin()) {
  add_action('admin_init', 'admin_init_googletagmanager');
  add_action('admin_menu', 'admin_menu_googletagmanager');
}

add_action('wp_head', 'googletagmanagerhead');

$placement_method = get_option('placement_method');

if ($placement_method == 'wp5'){
	add_action('wp_body_open', 'googletagmanagerbody');
	}
else{
	add_filter( 'body_class', 'gtm_add', 10000 );

	function gtm_add($classes){
		$tag_id = get_option('tag_id');
		$block = <<<BLOCK

		<!-- Google Tag Manager (noscript) -->
		<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=$tag_id
		height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
		<!-- End Google Tag Manager (noscript) -->

BLOCK;
	
		$classes[] = '">' . $block . '<br style="display:none';      
		return $classes;
	}
	
}
?>